package com.testcase;
import org.apache.log4j.Logger;

import java.io.*;
import java.sql.SQLException;

public class log4jExample{

   /* Get actual class name to be printed on */
   static Logger log = Logger.getLogger(log4jExample.class.getName());
   
   public static void main(String[] args)throws IOException,SQLException{
      log.debug("Hello this is a debug message");
      log.info("Hello this is an info message");
      
      
      log.debug("This is debug message");
      log.info("This is info message");
      log.warn("This is warn message");
      log.fatal("This is fatal message");
      log.error("This is error message");

   }
}